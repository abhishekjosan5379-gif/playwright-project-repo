import {test,expect} from '@playwright/test'
import {LoginPage} from '../pages/loginpage'
import validlogindata from '../utilities/testdatacredentials.json'
test('verify login with valid credentials',async({page})=>{
    const lp=new LoginPage(page)
    await lp.openApplication()
    const username=validlogindata.username
    const password=validlogindata.password
    await lp.clickLogin(username,password)
    await expect(page).toHaveURL('https://www.saucedemo.com/')
    
} )